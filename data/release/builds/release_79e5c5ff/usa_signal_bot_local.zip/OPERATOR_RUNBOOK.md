# USA Signal Bot - Operator Runbook
*Generated: 2026-05-08T19:46:58.736145+00:00*

## Overview
This runbook provides operational instructions for running the USA Signal Bot locally.
It covers installation, configuration, daily operations, and maintenance workflows.

## Installation
1. Ensure Python 3.10+ is installed.
2. Create a virtual environment: `python -m venv .venv`
3. Activate the environment (e.g., `source .venv/bin/activate` or `.venv\Scripts\activate`).
4. Install dependencies: `pip install -r requirements.txt`

## Configuration
Configuration is driven by YAML files in the `config/` directory.
- `default.yaml`: Base settings.
- `local.yaml`: User overrides (create from `local.example.yaml`).
- Profiles in `config/profiles/` can be used to set specific behavioral modes.

## Daily Operation
Recommended daily tasks:
1. Verify configuration: `python -m usa_signal_bot validate-config`
2. Check system health: `python -m usa_signal_bot health`
3. Run maintenance checks: `python -m usa_signal_bot maintenance-check --frequency daily`
4. Execute a local scan (dry-run): `python -m usa_signal_bot scan-dry-run`

## Weekly Maintenance
Recommended weekly tasks:
1. Run smoke tests: `python -m usa_signal_bot regression-run-smoke`
2. Evaluate system quality: `python -m usa_signal_bot quality-scorecard`
3. Generate maintenance report: `python -m usa_signal_bot maintenance-check --frequency weekly`
4. Create a backup: `python -m usa_signal_bot backup-create --scope reports_only`

## Backup Restore
Backups are created as zip archives containing system state (excluding secrets).
- Create backup: `python -m usa_signal_bot backup-create --scope config_only`
- Validate backup: `python -m usa_signal_bot backup-validate --backup <path_to_zip>`
- Restore dry-run: `python -m usa_signal_bot restore-dry-run --backup <path_to_zip> --target-dir <preview_dir>`

## Regression
Regression testing ensures stability against local baselines.
- Run smoke tests: `python -m usa_signal_bot regression-info`
- Run release rehearsal: `python -m usa_signal_bot release-rehearsal`

## Quality Gate
Quality gates ensure system readiness based on predefined metrics.
- Evaluate acceptance: `python -m usa_signal_bot acceptance-evaluate`

## Paper Trading
Local simulated paper trading allows realistic execution gap analysis without broker risk.
- View status: `python -m usa_signal_bot paper-info`

## Notifications
Notifications are sent via Telegram (if configured). Real sending is disabled by default.
- Test notification (dry-run): `python -m usa_signal_bot notification-dispatch-dry-run`

## Troubleshooting
If the system fails or behaves unexpectedly:
1. Check the logs in `data/logs/` or console output.
2. Ensure data directories exist and are writable.
3. Validate config profile: `python -m usa_signal_bot config-profile-validate --all`

## Safety Limitations
**CRITICAL SAFETY WARNINGS**
1. This system is for local research only. It is NOT a live trading bot.
2. It does NOT connect to any broker API (no Alpaca, IBKR, etc.).
3. It does NOT generate live or demo orders.
4. The outputs of this system do NOT constitute financial or investment advice.
5. Release packages and runbooks are strictly for local operations and are NOT live approvals.

## Command Reference
- `python -m usa_signal_bot smoke`: Run basic smoke tests
- `python -m usa_signal_bot health`: Check system health
- `python -m usa_signal_bot validate-config`: Validate configuration
- `python -m usa_signal_bot release-info`: Show release packaging info
- `python -m usa_signal_bot maintenance-info`: Show maintenance plans